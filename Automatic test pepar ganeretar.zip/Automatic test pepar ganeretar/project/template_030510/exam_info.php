<?php
@session_start();
include_once 'dbconfig.php';
$u=@$_SESSION['sun'];
$p=@$_SESSION['sup'];
$rem=false;
$msg1="";
$login=false;
if(verifyuser($u,$p,$rem))
{
$msg1="<br/>Mode: Admin , Welcome $u, <a href=logout.php><font color = red>Logout</font></a>";
$login=true;
}
else
{
	if(verifystudent($u,$p,$rem))
	{
	$msg1="<br/>Mode: Student , Welcome $u, <a href=logout.php>Logout</a>";
	$login=true;
	}
	else
	{
	
	header("Location:loginerr.php");
	}

}

?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>

	<title>Online Test</title>
	<link rel="stylesheet" href="style.css" type="text/css" charset="utf-8" />
<script language="javascript" src="calendarDateInput.js" ></script>
</head>

<body>
<div id="container">
	<div id="menu">

	<?php include "toplinks.php"; ?>
	
	</div>
	<div id="header">
		<div id="logo">
			<a href=" "><img src="images/logo.gif" alt="logo" border="0" /></a>
		</div>
<div id="right">
<?php
if(strlen($msg1)>0)
	{
echo $msg1;
	}

?>
</div>
		<div id="dja">
<form name=f1 id=f1  method=post>
<table BGCOLOR = BLACK align = center border=0 width=500>
<tr>
<td   width=200>Exam Id</td>

<td ><input type=text name=exam_id id=exam_id  maxlength=100 size=20/></td>
</tr>
<tr><td>End Date</td>
<td><script>DateInput('doe', true, 'YYYY-MM-DD')</script></td>
</tr>

<tr>
<td>Duration</td>

<td><input type=time   name=duration id=duration maxlength = 100 size=20 /></td>

</tr>
<tr>
<td>Topic</td>
<td><input type=text name=topic id=topic  maxlength = 100 size=20 /></td>
</tr>

<tr>
<td>Number Of Question</td>

<td><input type=text name=no_of_q id=no_of_q maxlength = 100 size=20 /></td>

</tr>

<tr >
<td>Branch</td>
<td><select  name=branch id=branch >
<option value="CSE">CSE</option>
<option value="IT">IT</option>
<option value="EC">EC</option>
</select></td>
</tr>

<tr>
<td>Sem</td>
<td><select  name=sem id=sem >
<option value="1st">1st</option>
<option value="2nd">2nd</option>
<option value="3rd">3rd</option>
<option value="4th">4th</option>
<option value="5th">5th</option>
<option value="6th">6th</option>

<option value="7th">7th</option>
<option value="8th">8th</option>
</select></td>
</tr>
<tr>
<td>Subject</td>
<td><input type=text name=sub id=sub maxlength = 100 size=20 /></td>

</tr>
</table>
<table>
<tr>
<td ><input type=submit name=save id=save value=" save " size=20 >
<input type=submit name=update id=update value="update" size=20 />
<input type=submit name=delete id=delete value="delete" size=20 />
<input type=submit name=list id=list value="   list   " size=20 />
<input type=submit name=Reset id=Reset value="reset" size=20 /></td>
</tr>
</table>

</form>
</div>

		<div id="welcome">
			<h2>Exam Info</h2>
<?php if($login==false)
{
?>
			<h2>Sign In</h2>
<form name=loginfrm id=loginfrm  class="searchform" method=post action=signin.php >
User Id &nbsp;&nbsp;
<input type=text name=userid id=userid size=17 />
Password 
<input type=password name=pwd id=pwd size=17 />
<p align=right>
<input type=submit id=lsubmit name=lsubmit value=login  class="button" /><br/>
</p>
New User <a href=signup.php>Signup Here</a>


</form>	
<?php
}
?>
		</div>
		<div class="clear">
<!-- content here -->

<?php

include_once 'class_info.php';

if(isset($_REQUEST['save'])||isset($_REQUEST['update'])||isset($_REQUEST['delete'])||isset($_REQUEST['list']))

 {

 $a=new exam();
 $a->set_exam_id($_REQUEST['exam_id']);
 $a->set_doe($_REQUEST['doe']);
 $a->set_duration($_REQUEST['duration']);
 $a->set_topic($_REQUEST['topic']);
 $a->set_no_of_q($_REQUEST['no_of_q']);
$a->set_branch($_REQUEST['branch']);
$a->set_sem($_REQUEST['sem']);
$a->set_sub($_REQUEST['sub']);

if(isset($_REQUEST['save']))
{
 $a->savetodb();
}

if(isset($_REQUEST['update']))
{
$a->modifirec();


}
if(isset($_REQUEST['delete']))
{
$a->removerec();
}
if(isset($_REQUEST['list']))
{
echo $a->searchdata();
}
}
?>
</div>

	<div id="middle">
</div></div>
	<div id="middle2"></div>
	<div id="content">
		<div id="left">
			<h2>UpComing Exams</h2>
			<?php @include 'upcoming.php'; ?>
			
		</div>
		<div id="right">
			<h2>Results</h2>
			<br /><br />
			<a class="more" href="results.php">more results</a>
		</div>
		<div class="clear"></div>
	</div>
	
	<div id="footer">
		<p>Copyright � Satyavaib softwares 2010  <a href="termsofuse.php">Terms of use</a><p>
		
	</div>

</div>
</body>
</html>