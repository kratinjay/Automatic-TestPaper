<FORM NAME="myForm" action="abc.php">
</FORM>

<SCRIPT LANGUAGE="JavaScript"><!--
setTimeout('document.myForm.submit()',5000);
//--></SCRIPT>
