<?php
$n=0;
@session_start();
	$possible = '23456789abcdfghjkmnpqrstvwxyz';
		$s = '';
		$i = 0;
		while ($i < 5) { 
			$s .= substr($possible, mt_rand(0, strlen($possible)-1), 1);
			$i++;
		}


include_once 'class_signup.php';
$msg="";
$capfail=false;
if(isset($_REQUEST['submit'])||isset($_REQUEST['delete']))
{
if($_REQUEST['verified']!=$_SESSION['capcha'])
{
$msg= "Capcha authentication failed";
$capfail=true;
}
if($_REQUEST['pwd']!=$_REQUEST['pwd1'])
{
$msg= "Password and Confirm password not Matched";
$capfail=true;
}

 $a=new signup();
 $a->set_username($_REQUEST['username']);
 $a->set_password($_REQUEST['pwd']);
 $a->set_name($_REQUEST['name']);
 $a->set_dob($_REQUEST['dob']);
 $a->set_gender($_REQUEST['gender']);
$a->set_verified($_REQUEST['verified']);

	if(isset($_REQUEST['submit']) && $capfail==false)
	{
		$n= $a->savetodb();
		$msg=" $n Record Saved";
	}

$_SESSION['capcha']=$s;	

}
else
{
$_SESSION['capcha']=$s;
}
?>

<html>

<head>
<link rel="stylesheet" href="style.css" type="text/css" charset="utf-8" />

<script language="Javascript" src="validation1.js"></script>
<script language="javascript" src="calendarDateInput.js" ></script>


<title>save form record </title>


</head>
<body>

<div id="container">
	<div id="menu">

	<?php include "toplinks.php"; ?>
	
	</div>
	<div id="header">


		<div id="right">

<?php echo "$msg <br/><br/>"; 
if($n==0)
{
?>
<form name =f1 id=f1 method=post >

<table BGCOLOR =#01111d align = right border=0>
<tr>
<td>User Id</td>

<td><input type=text name=username id=username  maxlength = 100 size =15/></td>

</tr>
<tr>
<td>Password</td>

<td><input type=password name=pwd id=pwd maxlength = 100 size =15 style="color:#01111d;background-color:lightyellow;height:25"/>
</td>

</tr>
<tr>
<td>Confirm Password</td>

<td><input type=password name=pwd1 id=pwd1 size=15  style="color:#01111d;background-color:lightyellow;height:25" onblur="chkpwd();" /></td>

</tr>
<tr>
<td>Name</td>

<td><input type= text name=name id=name size=15></td>

</tr>

<tr>
<td>Birthday</td>
<td>
<script>DateInput('dob', true, 'YYYY-MM-DD')</script>

</td>
</tr>

<tr>
<td>Gender</td>

<td>
<input type=radio name=gender id=gender value="M" />Male
<br/>
<input type=radio name=gender id=gender value="F" />Female
</td>

</tr>

<?php
echo "<tr>";
echo "<td>&nbsp;</tD><td  ><img src='capcha.php?s=$s' border=0>";
echo "<input type=hidden name=capcha id=capcha value='$s' >";
?>
</tD>
</tr>
<input type=hidden name=capcha id=capcha value=$s >

<tr>
<td>Verified</td>

<td><input type=text name=verified id=verified  maxlength = 100 size =15/></td>
</tr>
<tr>

<td><input type=submit name=submit id=submit value=" save " size = 10 </td>

<td><input type=reset name=Reset id=Reset value="reset" size = 10/></td>
</tr>
</table>
</form>			
<?php
}
?>
		</div>
		
		<div id="welcome">
		<h2>Admin Signup</h2>	
<!-- content here -->
			


		</div>
		<div class="clear"></div>
	</div>
	<div id="middle"></div>
	<div id="middle2"></div>
	<div id="content">
		<div id="left">


			<h2>UpComing Exams</h2>
			<?php @include 'upcoming.php'; ?>
			
		</div>
		<div id="right">
			<h2>Results</h2>
			<br /><br />
			<a class="more" href="results.php">more results</a>
		</div>
		<div class="clear"></div>
	</div>
	
	<div id="footer">
		<p>Copyright � Satyavaib softwares 2010  <a href="termsofuse.php">Terms of use</a><p>
		
	</div>

</div>

</body>
</html>