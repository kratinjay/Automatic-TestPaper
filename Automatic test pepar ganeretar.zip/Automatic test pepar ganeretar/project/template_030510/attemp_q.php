<?php
@session_start();
include_once 'dbconfig.php';
$u=@$_SESSION['sun'];
$p=@$_SESSION['sup'];
$rem=false;
$msg1="";
if(verifyuser($u,$p,$rem))
{
$msg1="<br/>Mode: Admin , Welcome $u, <a href=logout.php>Logout</a>";
}
else
{
	if(verifystudent($u,$p,$rem))
	{
	$msg1="<br/>Mode: Student , Welcome $u, <a href=logout.php>Logout</a>";
	}
	else
	{
	header("Location:loginerr.php");
	}

}
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>

	<title>Online Test</title>
	<link rel="stylesheet" href="style.css" type="text/css" charset="utf-8" />
</head>

<body>
<div id="container">
	<div id="menu">

	<?php include "toplinks.php"; ?>
	
	</div>
	<div id="header">
		<div id="logo">
			<a href=" "><img src="images/logo.gif" alt="logo" border="0" /></a>
			<h2>Attempt</h2>
		</div>
		<div id="right">
		<?php
		echo $msg1;
		?>
		</div>
		<div id="dja">
<br/><br/><br/><br/>
<form name=f1 id=f1 action=generate.php >
<table BGCOLOR = BLACK align = center border=0>
<?php
@session_start();
$u= $_SESSION['sun'];
$p= $_SESSION['sup'];
$query="select count(*) from 111_user_student where roll_no='$u' and pwd='$p'";

$ans=fetch_scalardata($query);
if($ans==0)
{
echo "<tr><tD colspan=2>user $u, is not allowed to give exam, <a href=logout.php>Logout</a>, and then login as a student</td></tR>";
}
else
{
?>
<tr>
<td>Enrollment No</td>
<td>
<?php echo $u; ?>
</td>
</tr>
<?php
$query="SELECT name,branch,sem,email,contact_no from 111_user_student where roll_no=".$_SESSION['sun'];
$rs=my_select($query);
$row=mysql_fetch_array($rs);
?>
<tr>
<td>Name of Student</tD>
<td><?php echo $row[0]; ?></td>
</tr>
<tr>
<td>Branch</tD>
<td><?php echo $row[1]; ?></td>
</tr>
<tr>
<td>Semister</tD>
<td><?php echo $row[2]; ?></td>
</tr>
<tr>
<td>Email</tD>
<td><?php echo $row[3]; ?></td>
</tr>
<tr>
<td>Exam Id</td>
<td>
<?php
$query="select exam_id,concat_ws(',',topic,doe) from 111_exam_info";
echo my_show_select('examid',$query,1,false,0);
?>
</td>
</tr>
<tr>

<td colspan=2 align=center><br/><input type=submit name=exam id=exam value=" give exam " size = 15/></td>

</tr>
<?php
}
?>
</table>

</form>

<?php

include_once 'class_attemp.php';

if(isset($_REQUEST['save'])||isset($_REQUEST['update'])||isset($_REQUEST['delete'])||isset($_REQUEST['list']))

 {

 $a=new attemp();
 $a->set_attemp_id($_REQUEST['attemp_id']);
 $a->set_email($_REQUEST['email']);
 $a->set_branch($_REQUEST['branch']);
$a->set_q_id($_REQUEST['q_id']);
$a->set_ans($_REQUEST['ans']);
$a->set_verified($_REQUEST['verified']);

if(isset($_REQUEST['save']))
{
 $a->savetodb();
}

if(isset($_REQUEST['update']))
{
$a->modifirec();
}
if(isset($_REQUEST['delete']))
{
$a->removerec();
}
if(isset($_REQUEST['list']))
{
echo "<br/> .$a->searchdata();<br/>";
}



}
?>


</div>
		<div id="welcome">

<!-- content here -->

		</div>
		<div class="clear"></div>
	</div>
	<div id="middle"></div>
	<div id="middle2"></div>
	<div id="content">
		<div id="left">
			
				<?php
if(strlen($msg1)>0)
	{
echo $msg1;
	}
else
	{

?>
			<h2>Sign In</h2>
<form name=loginfrm id=loginfrm  class="searchform" method=post action=signin.php >
User Id &nbsp;&nbsp;
<input type=text name=userid id=userid size=17 />
Password 
<input type=password name=pwd id=pwd size=17 />
<p align=right>
<input type=submit id=lsubmit name=lsubmit value=login  class="button" /><br/>
</p>
New User <a href=signup.php>Signup Here</a>


</form>	
<?php
}
?>

			<h2>UpComing Exams</h2>
			<?php @include 'upcoming.php'; ?>
			
		</div>
		<div id="right">
			<h2>Results</h2>
			<br /><br />
			<a class="more" href="results.php">more results</a>
		</div>
		<div class="clear"></div>
	</div>
	
	<div id="footer">
		<p>Copyright � Satyavaib softwares 2010  <a href="termsofuse.php">Terms of use</a><p>
		
	</div>

</div>
</body>
</html>
