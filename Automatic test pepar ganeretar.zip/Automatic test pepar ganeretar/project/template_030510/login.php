<?php
@session_start();
include_once 'dbconfig.php';
$u=@$_SESSION['sun'];
$p=@$_SESSION['sup'];
$rem=false;
$msg1="";
if(verifyuser($u,$p,$rem))
{
$msg1="<br/>Mode: Admin , Welcome $u, <a href=logout.php><font color = red>Logout</font></a>";
}
else
{
	if(verifystudent($u,$p,$rem))
	{
	$msg1="<br/>Mode: Student , Welcome $u, <a href=logout.php><font color = red>Logout</font></a>";
	}
	else
	{
	$msg1="";
	}

}
?>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

	<title>Online Test</title>
<script type='text/javascript' src='Validation1.js'></script>
	<link rel="stylesheet" href="style.css" type="text/css" charset="utf-8" />
</head>

<body>
<div id="container">
	<div id="menu">

	<?php include "toplinks.php"; ?>
	
	</div>
	<div id="header">
		<div id="logo">
			<a href=" "><img src="images/logo.gif" alt="logo" border="0" /></a>
		</div>
		<div id="dj"></div>
		<div id="welcome">
			<h2>Login Page</h2>
<!-- content here -->
			
<?php
if(strlen($msg1)>0)
echo $msg1;
else
{
?>
			<h2>Sign In</h2>
<form name=loginfrm id=loginfrm  class="searchform" method=get action=signin.php >
User Id &nbsp;&nbsp;
<input type=text name=userid id=userid size=17 />
Password 
<input type=password name=pwd id=pwd size=17 />
<br/>Mode
<br/>
<input type=radio name=mode id=mode value=student checked />Student
<input type=radio name=mode id=mode value=admin />admin
<p align=right>
<input type=submit id=lsubmit name=lsubmit value=login onClick="return validation1()" class="button" /><br/>
</p>

New User <a href=signup.php>Signup Here</a>


</form>	
<?php
}
?>

		</div>
		<div class="clear"></div>
	</div>
	<div id="middle"></div>
	<div id="middle2"></div>
	<div id="content">
		<div id="left">


			<h2>UpComing Exams</h2>
			<?php @include 'upcoming.php'; ?>
			
		</div>
		<div id="right">
			<h2>Results</h2>
			<br /><br />
			<a class="more" href="results.php">more results</a>
		</div>
		<div class="clear"></div>
	</div>
	
	<div id="footer">
		<p>Copyright � Satyavaib softwares 2010  <a href="termsofuse.php">Terms of use</a><p>
		
	</div>

</div>
</body>
</html>
