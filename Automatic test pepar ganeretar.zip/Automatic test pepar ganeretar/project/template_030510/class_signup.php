<?php
include_once 'dbconfig.php';
class signup
{
private $username;
private $password;
private $name;
private $dob;
private $gender;
private $verified;


//accessor and mutetar function for create



public function get_username()
{
	return $this->username;
}
public function set_username($x)
{
	$this->username=$x;
}
public function get_password()
{
	return $this->password;
}
public function set_password($x)
{
	$this->password=$x;
}
public function get_name()
{
	return $this->name;
}
public function set_name($x)
{
	$this->name=$x;
}

public function get_dob()
{
	return $this->dob;
}
public function set_dob($x)
{
	$this->dob=$x;
}
public function get_gender()
{
	return $this->gender;
}
public function set_gender($x)
{
	$this->gender=$x;
}

public function get_verified()
{
	return $this->verified;
}
public function set_verified($x)
{
	$this->verified=$x;
}

public function set_all($a,$b,$c,$d,$e,$f,$g,$h)
{
	$this->username=$a;
	$this->password=$b;
	$this->name=$c;
	$this->dob=$d;
	$this->gender=$e;
	$this->verified=$g;
}
public function display_all()
{
   $output="";
	$output.="<br/> username=".$this->username;
	$output.="<br/> password=".$this->password;
	$output.="<br/> name=".$this->name;
	$output.="<br/> dob=".$this->dob;
	$output.="<br/> gender=".$this->gender;
	$output.="<br/> verified=".$this->verified;
	$output.=fetch_scalardata($query);
	
}

public function savetodb()
	{
		$query="insert into 111_login_id values('$this->username','$this->password','$this->name','$this->dob','$this->gender','$this->verified')";
		$n=my_uid($query);
		return $n;	
	}

public function removerec()
	{
		$query="delete from 111_login_id  where username='$this->username' ";
		$n=my_uid($query);
		return $n;
	}
}
?>