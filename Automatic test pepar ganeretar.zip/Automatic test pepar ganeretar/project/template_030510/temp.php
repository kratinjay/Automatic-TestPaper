
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

	<title>Online Test</title>
	<link rel="stylesheet" href="style.css" type="text/css" charset="utf-8" />
</head>

<body>
<div id="container">
	<div id="menu">

	<?php include "toplinks.php"; ?>
	
	</div>
	<div id="header">
		<div id="logo">
			<a href=" "><img src="images/logo.gif" alt="logo" border="0" /></a>
		</div>
		<div id="dj"></div>
		<div id="welcome">
			<h2>Page Title</h2>
<!-- content here -->




		</div>
		<div class="clear"></div>
	</div>
	<div id="middle"></div>
	<div id="middle2"></div>
	<div id="content">
		<div id="left">
			<h2>UpComing Exams</h2>
			<?php @include 'upcoming.php'; ?>
			
		</div>
		<div id="right">
			<h2>Results</h2>
			<br /><br />
			<a class="more" href="results.php">more results</a>
		</div>
		<div class="clear"></div>
	</div>
	
	<div id="footer">
		<p>Copyright � Satyavaib softwares 2010  <a href="termsofuse.php">Terms of use</a><p>
		
	</div>

</div>
</body>
</html>
