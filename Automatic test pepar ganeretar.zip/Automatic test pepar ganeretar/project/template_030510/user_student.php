<?php
@session_start();
include_once 'dbconfig.php';
$u=@$_SESSION['sun'];
$p=@$_SESSION['sup'];
$rem=false;
$msg1="";
if(verifyuser($u,$p,$rem))
{
$msg1="<br/>Mode: Admin , Welcome $u, <a href=logout.php><font color = red>Logout</font></a>";
}
else
{
	if(verifystudent($u,$p,$rem))
	{
	$msg1="<br/>Mode: Student , Welcome $u, <a href=logout.php><font color = red>Logout</font></a>";
	}
	else
	{
	//header("Location:loginerr.php");
	}

}

$n=0;

	$possible = '23456789abcdfghjkmnpqrstvwxyz';
		$s = '';
		$i = 0;
		while ($i < 5) { 
			$s .= substr($possible, mt_rand(0, strlen($possible)-1), 1);
			$i++;
		}
?>

<html>

<head>
<link rel="stylesheet" href="style.css" type="text/css" charset="utf-8" />


<title>save form record </title>

<script language="Javascript" src="validation1.js"></script>
</head>
<body>

<div id="container">
	<div id="menu">

	<?php include "toplinks.php"; ?>
	
	</div>
	<div id="header">
		<div id="header">
		<div id="logo">
			<a href=" "><img src="images/logo.gif" alt="logo" border="0" /></a>
		</div>
		<div id="right">
		<?php echo $msg1; ?>
		</div>
		<div id="dja">
<?php

include_once 'class_s.php';
$msg="";
$capfail=false;
if(isset($_REQUEST['save'])||isset($_REQUEST['update'])||isset($_REQUEST['delete'])||isset($_REQUEST['list']))
{
if($_REQUEST['verified']!=$_SESSION['capcha'])
{
$msg= "Capcha authentication failed";
$capfail=true;
}
if($_REQUEST['pwd']!=$_REQUEST['pwd1'])
{
$msg= "Password and Confirm password not Matched";
$capfail=true;
}



 $a=new student();
 $a->set_roll_no($_REQUEST['roll_no']);
 $a->set_name($_REQUEST['name']);
 $a->set_branch($_REQUEST['branch']);
 $a->set_sem($_REQUEST['sem']);
 $a->set_email($_REQUEST['email']);
$a->set_pwd($_REQUEST['pwd']);
$a->set_verified($_REQUEST['verified']);
$a->set_contact_no($_REQUEST['contact_no']);

if(isset($_REQUEST['save']) && $capfail==false)
{
		$n= $a->savetodb();
		$msg=" $n Record Saved";

}

if(isset($_REQUEST['update']) && $capfail==false)
{
	$n=$a->modifirec();
	$msg=" $n Records modified";




}
if(isset($_REQUEST['delete']) && $capfail==false)
{
	$n=$a->removerec();
	$msg=" $n Records removed";

}
if(isset($_REQUEST['list']) && $capfail==false)
{
echo $a->searchdata();
}


$_SESSION['capcha']=$s;	

}
else
{
$_SESSION['capcha']=$s;
}

echo "$msg <br/><br/>"; 
if($n==0)
{

?>
<form name=f1 id=f1 method=post>

<table BGCOLOR =#01111d align=left border=0 width=500 >
<tr>
<td width=150>Roll Number:</td>

<td width=150	 ><input type=text name=roll_no id=roll_no  maxlength = 150 size=20  /></td>
<td width=200>&nbsp;</tD>

</tr>
<tr>
<td>Name:</td>

<td><input type=text name=name id=sname maxlength = 150 size=20 
onfocus="msg(sname_sugg,'enter alpha and space only')";
onkeyup="info(sname_info,this)";
onblur="chk_alpha(sname_error,this,5,sname_sugg)";/></td>
<td>
<span id=sname_sugg></span>
<span id=sname_info></span>
<span id=sname_error></span>
</td>

</tr>
<tr>
<td>Branch:</td>

<td><select  name=branch id=branch >
<option value="CSE">CSE</option>
<option value="IT">IT</option>
<option value="EC">EC</option>
</select></td>

</tr>
<tr>
<td >Sem:</td>

<td><select  name=sem id=sem >
<option value="1st">1st</option>
<option value="2nd">2nd</option>
<option value="3rd">3rd</option>
<option value="4th">4th</option>
<option value="5th">5th</option>
<option value="6th">6th</option>

<option value="7th">7th</option>
<option value="8th">8th</option>
</select></td>
</tr>

<tr>
<td>E-mail:</td>

<td><input type=text name=email id=email maxlength = 150 size=20  onfocus="chk_email(email_sugg,'enter alpha and space only')";
onkeyup="info(email_info,this)";
 /></td>
<td>
<span id=email_sugg></span>
<span id=email_info></span>
<span id=email_error></span>
</td>

</tr>

<tr >
<td>Password:</td>

<td><input type=password   name=pwd id=pwd maxlength = 150 size=20  style="color:#01111d;background-color:lightyellow;height:25"/></td>
<tr>
<td>Confirm Password:</td>

<td><input type=password name=pwd1 id=pwd1 size=20  style="color:#01111d;background-color:lightyellow;height:25" onblur="chkpwd();" /></td>

</tr>
</tr>
<tr>
<td >Contact No:</td>

<td><input type=text name=contact_no id=contact_no maxlength = 150 size=20 /></td>

</tr>

<tr>
<?php
echo "<td>&nbsp;</tD><td><img src='capcha.php?s=$s' border=0>";
echo "<input type=hidden name=capcha id=capcha value=$s >";
?>
</tD>
</tr>
<input type=hidden name=capcha id=capcha value=$s >
<tr>
<td>Verified</td>

<td><input type=text name=verified id=verified  maxlength = 150 size=20 /></td>

</tr>

<tr>
<td colspan=2>
<input type=submit name=save id=save value="submit" size=20 />
<input type=submit name=update id=update value="update" size=20 />

<input type=reset name=Reset id=Reset value="Reset" size =15/>
</td>
</tr>
</table>
</form>
<?php
}
?>

		</div>
		
		<div id="welcome">
			<h2>Student Registration</h2>

			
<!-- content here -->
			


		</div>
		<div class="clear"></div>
	</div>
	<div id="middle"></div>
	<div id="middle2"></div>
</div>
	<div id="content">
		<div id="left">


			<h2>UpComing Exams</h2>
			<?php @include 'upcoming.php'; ?>
			
		</div>
		<div id="right">
			<h2>Results</h2>
			<br /><br />
			<a class="more" href="results.php">more results</a>
		</div>
		<div class="clear"></div>
	</div>
	
	<div id="footer">
		<p>Copyright � Satyavaib softwares 2015  <a href="termsofuse.php">Terms of use</a><p>
		
	</div>

</div>

</body>
</html>