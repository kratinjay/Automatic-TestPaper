-- phpMyAdmin SQL Dump
-- version 3.2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 01, 2010 at 07:52 AM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `exam_form`
--

-- --------------------------------------------------------

--
-- Table structure for table `111_attempt_a`
--

CREATE TABLE IF NOT EXISTS `111_attempt_a` (
  `attempid` int(50) NOT NULL AUTO_INCREMENT,
  `rollno` int(120) NOT NULL,
  `examid` int(20) NOT NULL,
  `qid` int(100) NOT NULL,
  `ans` varchar(5) NOT NULL,
  `marks` int(100) NOT NULL,
  PRIMARY KEY (`attempid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `111_attempt_a`
--

INSERT INTO `111_attempt_a` (`attempid`, `rollno`, `examid`, `qid`, `ans`, `marks`) VALUES
(27, 115, 11, 11, 'a', 0),
(26, 115, 11, 12, 'a', 0),
(25, 115, 11, 9, 'a', 0),
(24, 115, 11, 1, 'a', 0),
(23, 115, 11, 11, 'a', 0),
(22, 115, 11, 12, 'a', 0),
(21, 115, 11, 9, 'a', 0),
(20, 115, 11, 1, 'a', 0),
(19, 115, 11, 11, 'a', 0),
(18, 115, 11, 12, 'a', 0),
(17, 115, 11, 9, 'a', 0),
(16, 115, 11, 1, 'a', 0),
(28, 115, 11, 1, 'a', 0),
(29, 115, 11, 9, 'a', 0),
(30, 115, 11, 12, 'a', 0),
(31, 115, 11, 11, 'a', 0),
(32, 115, 11, 1, 'a', 0),
(33, 115, 11, 9, 'a', 0),
(34, 115, 11, 11, 'a', 0),
(35, 115, 11, 13, 'b', 0),
(36, 115, 11, 9, 'c', 0),
(37, 115, 11, 1, 'a', 0),
(38, 115, 11, 18, 'a', 0),
(39, 115, 11, 13, 'a', 0);

-- --------------------------------------------------------

--
-- Table structure for table `111_attemp_q`
--

CREATE TABLE IF NOT EXISTS `111_attemp_q` (
  `attemp_id` int(12) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) DEFAULT NULL,
  `branch` varchar(200) DEFAULT NULL,
  `q_id` int(10) unsigned DEFAULT NULL,
  `ans` varchar(200) DEFAULT NULL,
  `verified` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`attemp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `111_attemp_q`
--


-- --------------------------------------------------------

--
-- Table structure for table `111_examlevel`
--

CREATE TABLE IF NOT EXISTS `111_examlevel` (
  `examid` int(100) NOT NULL,
  `level1` varchar(50) NOT NULL,
  `level2` varchar(40) NOT NULL,
  `level3` varchar(20) NOT NULL,
  PRIMARY KEY (`examid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `111_examlevel`
--

INSERT INTO `111_examlevel` (`examid`, `level1`, `level2`, `level3`) VALUES
(11, '2', '2', ''),
(1, '1', '2', '3'),
(0, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `111_exam_info`
--

CREATE TABLE IF NOT EXISTS `111_exam_info` (
  `exam_id` varchar(12) NOT NULL,
  `doe` date DEFAULT NULL,
  `duration` time DEFAULT NULL,
  `topic` varchar(10) DEFAULT NULL,
  `no_of_q` varchar(50) DEFAULT NULL,
  `branch` varchar(50) DEFAULT NULL,
  `sem` varchar(50) DEFAULT NULL,
  `sub` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`exam_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `111_exam_info`
--

INSERT INTO `111_exam_info` (`exam_id`, `doe`, `duration`, `topic`, `no_of_q`, `branch`, `sem`, `sub`) VALUES
('11', '2010-04-23', '00:30:00', '11', '11', 'CSE', '1st', ''),
('2', '2010-04-28', '00:30:00', 'ccna', '10', 'CSE', '6th', '');

-- --------------------------------------------------------

--
-- Table structure for table `111_login`
--

CREATE TABLE IF NOT EXISTS `111_login` (
  `user_id` varchar(12) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `sub` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `111_login`
--

INSERT INTO `111_login` (`user_id`, `name`, `sub`) VALUES
('vaibs', 'vaibhav', 'asa');

-- --------------------------------------------------------

--
-- Table structure for table `111_login_id`
--

CREATE TABLE IF NOT EXISTS `111_login_id` (
  `username` varchar(25) NOT NULL,
  `password` varchar(10) NOT NULL,
  `name` varchar(25) NOT NULL,
  `dob` date NOT NULL,
  `gender` set('M','F') NOT NULL,
  `verified` varchar(11) NOT NULL,
  PRIMARY KEY (`username`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `username_2` (`username`),
  KEY `username_3` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `111_login_id`
--

INSERT INTO `111_login_id` (`username`, `password`, `name`, `dob`, `gender`, `verified`) VALUES
('admin', 'admin', 'administrator', '0000-00-00', 'M', '1234'),
('vaibs', 'vaibs', 'vaibhav khatke', '2010-03-09', 'M', '12345'),
('vaibsnri', 'po', 'v', '2010-04-29', 'M', '0');

-- --------------------------------------------------------

--
-- Table structure for table `111_qu_paper`
--

CREATE TABLE IF NOT EXISTS `111_qu_paper` (
  `q_id` int(200) NOT NULL AUTO_INCREMENT,
  `examid` varchar(10) DEFAULT NULL,
  `question` varchar(500) DEFAULT NULL,
  `op1` varchar(200) DEFAULT NULL,
  `op2` varchar(200) DEFAULT NULL,
  `op3` varchar(200) DEFAULT NULL,
  `op4` varchar(200) DEFAULT NULL,
  `correct_ans` varchar(200) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `topic` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`q_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `111_qu_paper`
--

INSERT INTO `111_qu_paper` (`q_id`, `examid`, `question`, `op1`, `op2`, `op3`, `op4`, `correct_ans`, `level`, `topic`) VALUES
(1, '11', 'choose valid identifiers from the following', '$int', 'bytes', '$1', 'all of the above', 'all of the above', 1, 'misc'),
(9, '11', 'what is default layout manager for applets and panel?', 'flow', 'border', 'bg', 'none', 'flow', 1, 'misc'),
(10, 'java1', 'which is best front end', 'php', 'jsp', 'asp', 'cgi-perl', 'php', 1, 'misc'),
(11, '11', 'which is best back end', 'oracle 12', 'my sql 5', 'sybase', 'db2', 'oracle 12', 2, 'misc'),
(12, '11', 'data connection can be done in java with the help of ?', 'jdbc', 'odbc', 'both', 'none', 'both', 2, 'misc'),
(13, '11', 'browser compiles jsp into ?', 'servlet', 'cgi', 'html', 'none', 'servlet', 2, 'misc'),
(14, 'java1', 'a signed data type has equal number of non zero and negative valuse available', 'true', 'false', 'no answer', '', 'false', 3, 'misc'),
(15, 'java1', 'satyendra is a ', 'programmer', 'developer', 'designer', 'not sure', 'not sure', 3, 'misc'),
(16, '1', 'what did the javadoc command does?', 'create documentation', 'create html', 'create csv', 'create word', 'create html', 2, 'java2'),
(17, '', 'n', 'knk', 'nk', 'n', 'nk', 'option1', 2, 'saklk'),
(18, '11', 'akk', 'hkh', 'khk', 'hk', 'hk', 'option2', 2, 'rhce'),
(19, '11', 'Who is the ceo of intel cooperation ?', 'paul ottolini', 'james bond', 'paul ritchi ', 'satyendra yadav', 'option1', 3, 'c++'),
(20, '11', 'Which of the following is not a web server ?', 'apache tomcat', 'IIS', 'samba', 'mysql server', 'option4', 3, 'misce'),
(21, '11', 'the following ip 10.0.0.1  belongs to which class ?', 'class a', 'class b', 'class c', 'class d', 'option1', 1, 'networking');

-- --------------------------------------------------------

--
-- Table structure for table `111_user_student`
--

CREATE TABLE IF NOT EXISTS `111_user_student` (
  `roll_no` varchar(12) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `branch` varchar(10) DEFAULT NULL,
  `sem` varchar(10) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `pwd` varchar(50) DEFAULT NULL,
  `verified` varchar(50) DEFAULT NULL,
  `contact_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`roll_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `111_user_student`
--

INSERT INTO `111_user_student` (`roll_no`, `name`, `branch`, `sem`, `email`, `pwd`, `verified`, `contact_no`) VALUES
('0115cs07112', 'vaibhav khatke', 'cse', '6', 'vaibhav_khatke@rediff.com', 'pololo', '123456', 2147483647),
('0115cs071112', 'vaibhav', 'CSE', '6th', 'vaibhav_khatke@redif', '', '', 0),
('0115', 'vaibhav khatke', 'CSE', '4th', 'vaibha', 'pololo', 'bsszb4', 2147483647);
