<?php
session_start();
include_once 'dbconfig.php';
@$u=$_SESSION['sun'];
@$p=$_SESSION['sup'];
$rem=false;
$output="";
if((verifyuser($u,$p,$rem)))
{
header("Location:index.php");
}
if(isset($_REQUEST['lsubmit']))
{
$u=$_REQUEST['userid'];
$p=$_REQUEST['pwd'];
$m=$_REQUEST['mode'];
if(isset($_REQUEST['rem']))
$rem=true;
else
$rem=false;
//echo "<br/>$u,$p,$m";
if (verifyuser($u,$p,$rem) && $m=="admin")
{
$output="<br/>Mode : admin Welcome $u,<a href='logout.php'><font color = red>Logout</font></a>";
header("Location:login.php?msg='$output'");
}
else
{

if (verifystudent($u,$p,$rem)  && $m=="student")
{
$output="<br/>Mode : student Welcome $u,<a href='logout.php'>logout</a>";
header("Location:login.php?msg='$output'");
}
else
{
$output="<br/>Welcome Guest, <a href=login.php>Login</a>";
header("Location:loginerr.php");
}

}

}

?>