<?php
@session_start();
include_once 'dbconfig.php';
$u=@$_SESSION['sun'];
$p=@$_SESSION['sup'];
$rem=false;
$msg1="";
$login=false;
if(verifyuser($u,$p,$rem))
{
$msg1="<br/>Mode: Admin , Welcome $u, <a href=logout.php><font color = red>Logout</font></a>";
$login=true;
}
else
{
	
	
	header("Location:loginerr.php");
	

}

include_once 'class_que.php';

if(isset($_REQUEST['ok']))

 {

 $a=new que();
 $a->set_q_id($_REQUEST['q_id']);
 $a->set_examid($_REQUEST['examid']);
 $a->set_question($_REQUEST['question']);
 $a->set_op1($_REQUEST['op1']); 
 $a->set_op2($_REQUEST['op2']);
 $a->set_op3($_REQUEST['op3']);
 $a->set_op4($_REQUEST['op4']);
 $a->set_correct_ans($_REQUEST['correct_ans']);
 $a->set_level($_REQUEST['level']);
 $a->set_topic($_REQUEST['topic']);

 

 $a->savetodb();
}

?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>

	<title>Online Test</title>
	<link rel="stylesheet" href="style.css" type="text/css" charset="utf-8" />
</head>

<body>
<div id="container">
	<div id="menu">

	<?php include "toplinks.php"; ?>
	
	</div>
	<div id="header">
		<div id="right">
<?php
echo $msg1;
?>

</div>
		<div id="welcome">
		<h2>Insert Questions</h2>

<!-- content here -->
<form name = f1 id =f1 >
<table BGCOLOR = BLACK align=left border=0>
<tr>
<td>Enter q_id</td>
<td><input type=text name=q_id id=q_id  maxlength = 100 size = 15/></td>
</tr>
<tr>
<tr>
<td>Select exam</td>
<td>
<?php
$query="select exam_id,concat_ws(',',topic,doe) from 111_exam_info";
echo my_show_select('examid',$query,1,false,0);
?>
</td>
</tr>
<td>Level</td>
<td><select name=level id=level >
<option value=1>1</option>
<option value=2>2</option>
<option value=3>3</option>
</select></td>

</tr>

<tr>
<td>Topic</td>
<td><input type=text name=topic id=topic ></td>

</tr>


<tr>
<td valign=top>Question</td>
<td><TEXTAREA  name=question id=question  rows=3 wrap=VIRTUAL cols=30></TEXTAREA></td>

</tr>

<tr>
<td valign="top">a</td>
<td><TEXTAREA  name=op1 id=op1  rows=3 wrap=VIRTUAL cols=30></TEXTAREA></td>
</tr>

<tr>
<td valign="top">b</td>
<td><TEXTAREA  name=op2 id=op2  rows=3 wrap=VIRTUAL cols=30></TEXTAREA></td>
</tr>
<tr>
<td valign="top">c</td>
<td><TEXTAREA  name=op3 id=op3  rows=3 wrap=VIRTUAL cols=30></TEXTAREA></td>
</tr>
<tr>
<td valign="top">d</td>
<td><TEXTAREA  name=op4 id=op4  rows=3 wrap=VIRTUAL cols=30></TEXTAREA></td>

</tr>

<tr>
<td valign="top">Correct Answer</td>
<td>
<select name=correct_ans id=correct_ans>
<option value=a>a</option>
<option value=b>b</option>
<option value=c>c</option>
<option value=d>d</option>
</select>

</td>
</tr>


<tr>
<td><input type=submit name=ok id=ok value="OK" size = 15/></td>
<td><input type=reset name=Reset id=Reset value="reset" size = 10/></td>


</tr>
</table>

</form>


</div>
		<div class="clear">

</div>
	</div>
	<div id="middle"></div>
	<div id="middle2"></div>
	<div id="content">
		<div id="left">
			<h2>UpComing Exams</h2>
			<?php @include 'upcoming.php'; ?>
			
		</div>
		<div id="right">
			<h2>Results</h2>
			<br /><br />
			<a class="more" href="results.php">more results</a>
		</div>
		<div class="clear"></div>
	</div>
	
	<div id="footer">
		<p>Copyright � Satyavaib softwares 2010  <a href="termsofuse.php">Terms of use</a><p>
		
	</div>

</div>
</body>
</html>
