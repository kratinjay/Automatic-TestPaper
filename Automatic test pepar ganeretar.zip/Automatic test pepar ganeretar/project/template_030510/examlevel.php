<?php
@session_start();
include_once 'dbconfig.php';
$u=@$_SESSION['sun'];
$p=@$_SESSION['sup'];
$rem=false;
$msg1="";
$login=false;
if(verifyuser($u,$p,$rem))
{
$msg1="<br/>Mode: Admin , Welcome $u, <a href=logout.php><font color = red>Logout</font></a>";
$login=true;
}
else
{
	if(verifystudent($u,$p,$rem))
	{
	$msg1="<br/>Mode: Student , Welcome $u, <a href=logout.php><font color = red>Logout</font></a>";
	$login=true;
	}
	else
	{
	
	header("Location:loginerr.php");
	}

}

include_once 'class_examlevel.php';
$msg="";
if(isset($_REQUEST['ok']))

 {

 $a=new examlevel();
 $a->set_examid($_REQUEST['examid']);
 $a->set_level1($_REQUEST['level1']); 
 $a->set_level2($_REQUEST['level2']);
 $a->set_level3($_REQUEST['level3']);
 

$n=$a->savetodb();
$msg.= "<br/>$n record(s) saved";
$x=$_REQUEST['examid'];
$msg.= "<a href='generate.php?examid=$x'>Generate Paper</a>";

}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>ONLINE EXAM <?=$title?></title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<div id="head_menu">
&bull; <a href="http://www.atrise.com/buy/">1</a>
&bull; <a href="http://www.atrise.com/support/">2</a>
</div>

<div id="container">
	<div id="menu">

	<?php include "toplinks.php"; ?>
	
	</div>
	<div id="header">
		<div id="logo">
			<a href=" "><img src="images/logo.gif" alt="logo" border="0" /></a>
		
		</div>
		<div id="right">
<?php
echo $msg1;
?>

</div>
		<div id="welcome">
			<h2>Select level</h2>
<!-- content here -->

<form name = f1 id =f1 >
<table BGCOLOR = BLACK align = center border=0>
<tr>
<td>Exam Id</td>
<td>
<?php
$query="select exam_id,concat_ws(',',topic,doe) from 111_exam_info";
echo my_show_select('examid',$query,1,false,0);
?>
</td>
</tr>

<tr>
<td>LEVEL1</td>
<td><input type=text name=level1 id=level1 size=10/ >
</tr>

<tr>
<td>LEVEL2</td>
<td><input type=text name=level2 id=level2 size=10/ >
</tr>

<tr>
<td>LEVEL3</td>
<td><input type=text name=level3 id=level3 size=10/ >
</tr>

<tr>
<td><input type=submit name=ok id=ok value="OK" size = 15/></td>
<td><input type=reset name=Reset id=Reset value="reset" size = 10/></td>


</tr>
</table>

</form>



		</div>
		<div class="clear">
<?php echo "<br/>$msg"; ?>
</div>

	<div id="middle"></div>
	<div id="middle2"></div></div>
	<div id="content">
		<div id="left">
			<h2>UpComing Exams</h2>
			<?php @include 'upcoming.php'; ?>
			
		</div>
		<div id="right">

			<h2>Results</h2>
			<br /><br />
			<a class="more" href="results.php">more results</a>
		</div>
		<div class="clear"></div>
	</div>
	
	<div id="footer">
		<p>Copyright � Satyavaib softwares 2010  <a href="termsofuse.php">Terms of use</a><p>
		
	</div>

</div>
</body>
</html>
