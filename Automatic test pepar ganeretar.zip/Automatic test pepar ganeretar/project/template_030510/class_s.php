<?php
include_once 'dbconfig.php';
class student
{
private $roll_no;
private $name;
private $branch;
private $sem;
private $email;
private $pwd;
private $verified;
private $conact_no;


//accessor and mutetar function for create



public function get_roll_no()
{
	return $$this->roll_no;
}
public function set_roll_no($x)
{
	$this->roll_no=$x;
}
public function get_name()
{
	return $this->name;
}
public function set_name($x)
{
	$this->name=$x;
}
public function get_branch()
{
	return $this->branch;
}
public function set_branch($x)
{
	$this->branch=$x;
}
public function get_sem()
{
	return $this->sem;
}
public function set_sem($x)
{
	$this->sem=$x;
}
public function get_email()
{
	return $this->email;
}
public function set_email($x)
{
	$this->email=$x;
}

public function get_pwd()
{
	return $this->pwd;
}
public function set_pwd($x)
{
	$this->pwd=$x;
}
public function get_verified()
{
	return $this->verified;
}
public function set_verified($x)
{
	$this->verified=$x;
}
public function get_contact_no()
{
	return $this->contact_no;
}
public function set_contact_no($x)
{
	$this->contact_no=$x;
}


public function set_all($a,$b,$c,$d,$e,$f,$g,$h)
{
	$this->roll_no=$a;
	$this->name=$b;
	$this->branch=$c;
	$this->sem=$d;
	$this->email=$e;
	$this->pwd=$f;
	$this->verified=$g;
	$this->contact_no=$h;
}
public function display_all()
{
   $output="";
	$output.="<br/> roll_no=".$this->roll_no;
	$output.="<br/> student name=".$this->name;
	$output.="<br/> branch=".$this->branch;
	$output.="<br/> sem=".$this->sem;
	$output.="<br/> email=".$this->email;
	$output.="<br/>pwd=".$this->pwd;
	$output.="<br/> verified=".$this->verified;
	$output.="<br/> contact no=".$this->contact_no;
	
	$output.=fetch_scalardata($query);
	
}

public function savetodb()
	{
		$query="insert into 111_user_student values('$this->roll_no','$this->name','$this->branch','$this->sem','$this->email','$this->pwd','$this->verified','$this->contact_no')";



		//echo "<br/>$query";
		$n=my_uid($query);
		return $n;
	
	}

public function modifirec()
	{
		$query="update 111_user_student set name='$this->name',branch='$this->branch',sem='$this->sem',email='$this->email',pwd='$this->pwd',
		verified='$this->verified',contact_no='$this->contact_no' where roll_no='$this->roll_no' ";


		//echo "<br/>$query";
		$n=my_uid($query);
		
		return $n;
	}







public function removerec()
	{
$query="delete from 111_user_student  where roll_no='$this->roll_no' ";
echo "<br/>$query";
$n=my_uid($query);
return $n;

    }

public function searchdata()
{
$query="select * from 111_user_student";
echo "<br/>$query";
$rs=my_select($query);
$output="";
while($row=mysql_fetch_array($rs))
{
	foreach($row as $k=>$v)
		{
			if(!(is_numeric($k)))
			{
				$output.="<br/>$k is $v";
				$output.="<hr/>";
			}

		}
}
return $output;
}





}




?>