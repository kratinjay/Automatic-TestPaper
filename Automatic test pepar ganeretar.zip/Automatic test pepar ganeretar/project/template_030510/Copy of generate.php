<?php
include_once 'dbconfig.php';
@session_start();
include_once 'dbconfig.php';
$u=@$_SESSION['sun'];
$p=@$_SESSION['sup'];
$rem=false;
$msg1="";
$login=false;
$rollno=0;
if(verifyuser($u,$p,$rem))
{
$msg1="<br/>Mode: Admin , Welcome $u, <a href=logout.php><font color = red>Logout</font></a>";
$login=true;
}
else
{
	if(verifystudent($u,$p,$rem))
	{
	$msg1="<br/>Mode: Student , Welcome $u, <a href=logout.php><font color = red>Logout</font></a>";
	$login=true;
	}
	else
	{
	
	header("Location:loginerr.php");
	}}

$rollno=$u;
?>





<html xmlns="http://www.w3.org/1999/xhtml">
<head>

	<title>Online Test</title>
	<link rel="stylesheet" href="style.css" type="text/css" charset="utf-8" />
 <script type="text/javascript" >


var hour=00;  //specify hours for counter
var min=00;       // specify minutes 
var second = 21;    // specify the seconds
var lab = 'cd';  // id of the entry on the page where the counter is to be inserted


var hour,min,second,lab;
function settime(h,m,s,spid)
{
hour=h;
min=m;
second=s;
lab=spid;
//alert (m);
loaded(lab,start);
}

function start() 
{
	displayCountdown(setCountdown(hour,min,second),lab);
}
loaded(lab,start);
var pageLoaded = 0; 
window.onload = function() {pageLoaded = 1;}
function loaded(i,f) 
{
	if (document.getElementById && document.getElementById(i) != null) 
		f(); 
	else if (!pageLoaded) 
		setTimeout('loaded(\''+i+'\','+f+')',100);
}
function setCountdown(hour,min,second) 
{
	if(hour>0)
	min=min+hour*60;
	c = setC(min,second); 
return c;
} 
function setC(min,second) 
{
if(min>0)
second=min*60+second;
return Math.floor(second);
}
function displayCountdown(countdn,cd) 
{
//alert(countdn);
	if (countdn < 0)
	{
		//document.getElementById(cd).innerHTML = "Sorry, you are too late."; 
		//document.getElementById('form1').submit();
		alert('abc');
		
		//window.location='abc.html';
		//__doPostBack('__Page', 'time');
    }
	else 
	{
		var secs = countdn % 60; 
		if (secs < 10) 
			secs = '0'+secs;
		var countdn1 = (countdn - secs) / 60;
		var mins = countdn1 % 60; 
		if (mins < 10) 
			mins = '0'+mins;
		countdn1 = (countdn1 - mins) / 60;
		var hours = countdn1 % 24;
		document.getElementById(cd).innerHTML = hours+' : '+mins+' : '+secs;
		setTimeout('displayCountdown('+(countdn-1)+',\''+cd+'\');',999);
	}
}

</script>
</head>

<body>
<div id="container">
	<div id="menu">

	<?php include "toplinks.php"; ?>
	
	</div>
	<div id="header">
		<div id="logo">
<img src="images/logo.gif" alt="logo" border="0" />











<?php
$x=$_REQUEST['examid'];
$examid=$x;
$query="select * from  111_exam_info where exam_id='$x'";
$rs=my_select($query);
$row=mysql_fetch_array($rs);

echo "<table bgcolor= blue width=600>";
	foreach($row as $k=>$v)
		{
                 echo "<tr bgcolor=blue >"; 
			if(!(is_numeric($k)))
			{
echo "<td>$k</td>";							
echo "<td>$v</td>";
			}

echo "</tr>";
		}

echo "</table>";
?>
<table bgcolor=blue width=600>
<tr>
<td valign=middle><h3>Time Remaining :</h3></td>
<td><h3><span id="cd" style ="left:100px;"></span></h3></td>
</tr>
</table>
	
<a href="#level1">Level-1</a> |<a href="#level2">Level-2</a>|<a href="#level3">Level-3</a>| 
<br/><br/>

<?php
$s=$row['duration'];

$t=explode(':',$s);

//echo "$t[0]-$t[1]-$t[2]";
?>
<!-- content here -->
<form NAME="myForm" id="myForm"  method = post>

<?php
echo "<script language='javascript'>";
echo "settime($t[0],$t[1],$t[2],'cd');";
echo "</script>";
?>
		</div>
		<div id="welcome">
<?php


$query="select * from 111_examlevel where examid=$x";
$rs=my_select($query);
$row=mysql_fetch_array($rs);
$l1q=$row[1];
$l2q=$row[2];
$l3q=$row[3];

$l1=array();
$l2=array();
$l3=array();
$query1="Select q_id from 111_qu_paper where level=1 and examid=$x";
$rs=my_select($query1);
while($row=mysql_fetch_array($rs))
{
$l1[]=$row[0];

}
//echo "<hr/>";
//print_r($l1);

$query2="Select q_id from 111_qu_paper where level=2  and examid=$x";
$rs=my_select($query2);
while($row=mysql_fetch_array($rs))
{
$l2[]=$row[0];
}
//echo "<hr/>";
//print_r($l2);

$query3="Select q_id from 111_qu_paper where level=3  and examid=$x";
$rs=my_select($query3);
while($row=mysql_fetch_array($rs))
{
$l3[]=$row[0];
}
//echo "<hr/>";
//print_r($l3);

shuffle($l1);
shuffle($l2);
shuffle($l3);

$i=1;

echo "<hr/><a name='level1'><b>     LEVEL-1</b></a><br/>";

foreach($l1 as $x)
{
$query4="Select * from 111_qu_paper where  q_id=$x";
$rs=my_select($query4);
$row=mysql_fetch_array($rs);
echo "<table width=600>";
echo "<tr><td colspan=2>&nbsp;</td></tr>";
echo "<tr>";
echo "<td width=80> Q.No $i </td>";
echo "<td align=left width=520> :$row[2] </td>";
echo "</tr>";
echo "<tr>";
echo "<td>a :<input type=radio name=a_{$x} id=a_{$x} value='$x,a' /></td><td align=left>$row[3]</td></tr>";
echo "<tr>";
echo "<td>b :<input type=radio name=a_{$x} id=a_{$x} value='$x,b' /></td><td align=left>$row[4]</td></tr>";
echo "<tr>";
echo "<td>c :<input type=radio name=a_{$x} id=a_{$x} value='$x,c' /></td><td align=left>$row[5]</td></tr>";
echo "<tr>";
echo "<td>d :<input type=radio name=a_{$x} id=a_{$x} value='$x,d' /></td><td align=left>$row[6]</td></tr>";
echo "</table>";


$i++;
if($i>$l1q)
	break;
}


$i=1;
echo "<hr/><a name='level2'><b>     LEVEL-2</b></a><br/>";

foreach($l2 as $x)
{
$query4="Select * from 111_qu_paper where  q_id=$x";
$rs=my_select($query4);
$row=mysql_fetch_array($rs);
/*
echo "<br/><br/>S.No $i";
echo "<br/>Question :$row[2]";
echo "<br/>a :$row[3]";
echo "<input type=radio name=a_{$x} id=a_{$x} value='$x,a' />";
echo "<br/>b :$row[4]";
echo "<input type=radio name=a_{$x} id=a_{$x} value='$x,b' />";
echo "<br/>c :$row[5]";
echo "<input type=radio name=a_{$x} id=a_{$x} value='$x,c' />";
echo "<br/>d :$row[6]";
echo "<input type=radio name=a_{$x} id=a_{$x} value='$x,d' />";
*/
echo "<table width=600>";
echo "<tr><td colspan=2>&nbsp;</td></tr>";
echo "<tr>";
echo "<td width=80> Q.No $i </td>";
echo "<td align=left width=520> :$row[2] </td>";
echo "</tr>";
echo "<tr>";
echo "<td>a :<input type=radio name=a_{$x} id=a_{$x} value='$x,a' /></td><td align=left>$row[3]</td></tr>";
echo "<tr>";
echo "<td>b :<input type=radio name=a_{$x} id=a_{$x} value='$x,b' /></td><td align=left>$row[4]</td></tr>";
echo "<tr>";
echo "<td>c :<input type=radio name=a_{$x} id=a_{$x} value='$x,c' /></td><td align=left>$row[5]</td></tr>";
echo "<tr>";
echo "<td>d :<input type=radio name=a_{$x} id=a_{$x} value='$x,d' /></td><td align=left>$row[6]</td></tr>";
echo "</table>";
$i++;
if($i>$l2q)
	break;
}


$i=1;
echo "<hr/><a name='level3'><b>LEVEL-3</b></a><br/>";
foreach($l3 as $x)
{
$query4="Select * from 111_qu_paper where  q_id=$x";
$rs=my_select($query4);
$row=mysql_fetch_array($rs);
/*
echo "<br/><br/>S.No $i";
echo "<br/>Question :$row[2]";
echo "<br/>a :$row[3]";
echo "<input type=radio name=a_{$x} id=a_{$x} value='$x,a' />";
echo "<br/>b :$row[4]";
echo "<input type=radio name=a_{$x} id=a_{$x} value='$x,b' />";
echo "<br/>c :$row[5]";
echo "<input type=radio name=a_{$x} id=a_{$x} value='$x,c' />";
echo "<br/>d :$row[6]";
echo "<input type=radio name=a_{$x} id=a_{$x} value='$x,d' />";
*/
echo "<table width=600>";
echo "<tr><td colspan=2>&nbsp;</td></tr>";
echo "<tr>";
echo "<td width=80> Q.No $i </td>";
echo "<td align=left width=520> :$row[2] </td>";
echo "</tr>";
echo "<tr>";
echo "<td>a :<input type=radio name=a_{$x} id=a_{$x} value='$x,a' /></td><td align=left>$row[3]</td></tr>";
echo "<tr>";
echo "<td>b :<input type=radio name=a_{$x} id=a_{$x} value='$x,b' /></td><td align=left>$row[4]</td></tr>";
echo "<tr>";
echo "<td>c :<input type=radio name=a_{$x} id=a_{$x} value='$x,c' /></td><td align=left>$row[5]</td></tr>";
echo "<tr>";
echo "<td>d :<input type=radio name=a_{$x} id=a_{$x} value='$x,d' /></td><td align=left>$row[6]</td></tr>";
echo "</table>";
$i++;
if($i>$l3q)
	break;
}

?>
 </div>
		<div class="clear">
<input type=submit name=submit id=submit value="done" /> </div>
	</div>
	<div id="middle"></div>
	<div id="middle2"></div>
	<div id="content">
		<div id="left">
			<h2>UpComing Exams</h2>
			<?php @include 'upcoming.php'; ?>
			
		</div>
		<div id="right">
			<h2>Results</h2>
			<br /><br />
			<a class="more" href="results.php">more results</a>
		</div>
		<div class="clear"></div>
	</div>
	
	<div id="footer">
		<p>Copyright � Satyavaib softwares 2010  <a href="termsofuse.php">Terms of use</a><p>
		
	</div>

</div>




</form>
	
<?php
if(isset($_REQUEST['submit']))
{
echo "<Br/> Rollno is ".$rollno;
echo "<br/>Exam id is :".$examid;
foreach($_REQUEST as $k=>$v)
{
	if(substr($k,0,2)=="a_")
	{
		//echo "<br/>$k is $v";
		$arr=explode(",",$v);
		$qid=$arr[0];
		
		$ans=$arr[1];
	echo "<br/>$qid, $ans";
$query="select correct_ans from 111_qu_paper where examid='$examid' and q_id=$qid";
$c_ans=fetch_scalardata($query);
if(trim($ans)==trim($c_ans))
$marks=$correct;
else
$marks=$incorrect;
$query="insert into 111_attempt_a (rollno,examid,qid,ans,marks) values ('$rollno','$examid','$qid','$ans','$marks')";
//
$n=my_uid($query);
	}
}	
}

?>

</body>
</html>
