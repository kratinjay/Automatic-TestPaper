<?php
session_start();
$_SESSION['sun']="";
$_SESSION['sup']="";
session_destroy();
header("Location:index.php");
?>