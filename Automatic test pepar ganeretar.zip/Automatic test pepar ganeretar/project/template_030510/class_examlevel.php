<?php
include_once 'dbconfig.php';
class examlevel
{
private $examid;
private $level1;
private $level2;
private $level3;



//accessor and mutetar function for create



public function getexamid()
{
	return $this->examid;
}
public function set_examid($x)
{
	$this->examid=$x;
}
public function get_level1()
{
	return $this->level1;
}
public function set_level1($x)
{
	$this->level1=$x;
}
public function get_level2()
{
	return $this->level2;
}
public function set_level2($x)
{
	$this->level2=$x;
}

public function get_level3()
{
	return $this->level3;
}
public function set_level3($x)
{
	$this->level3=$x;
}

public function set_all($a,$b,$c,$d)
{
	$this->examid=$a;
	$this->level1=$b;
	$this->level2=$c;
	$this->level3=$d;
}
	
public function display_all()
{
   $output="";
	$output.="<br/> examid=".$this->examid;
	$output.="<br/> level1=".$this->level1;
	$output.="<br/> level2=".$this->level2;
	$output.="<br/> level3=".$this->level3;
		
	$output.=fetch_scalardata($query);
	
}

public function savetodb()
	{
		$query="replace into 111_examlevel
 	values('$this->examid','$this->level1','$this->level2','$this->level3')";



		echo "<br/>$query";
		$n=my_uid($query);
return $n;
	}

}




?>