<?php
include_once 'dbconfig.php';
class que
{
private $q_id;
private $examid;
private $question;
private $op1;
private $op2;
private $op3;
private $op4;
private $correct_ans;
private $level;
private $topic;


//accessor and mutetar function 

public function get_q_id()
{
	return $this->q_id;
}
public function set_q_id($x)
{
	$this->q_id=$x;
}


public function get_examid()
{
	return $this->examid;
}
public function set_examid($x)
{
	$this->examid=$x;
}
public function get_question()
{
	return $this->question;
}
public function set_question($x)
{
	$this->question=$x;
}
public function get_op1()
{
	return $this->op1;
}
public function set_op1($x)
{
	$this->op1=$x;
}
public function get_op2()
{
	return $this->op2;
}
public function set_op2($x)
{
	$this->op2=$x;
}
public function get_op3()
{
	return $this->op3;
}
public function set_op3($x)
{
	$this->op3=$x;
}
public function get_op4()
{
	return $this->op4;
}
public function set_op4($x)
{
	$this->op4=$x;
}

public function get_correct_ans()
{
	return $this->correct_ans;
}
public function set_correct_ans($x)
{
	$this->correct_ans=$x;
}

public function get_level()
{
	return $this->level;
}
public function set_level($x)
{
	$this->level=$x;
}
public function get_topic()
{
	return $this->topic;
}
public function set_topic($x)
{
	$this->topic=$x;
}

public function set_all($a,$b,$c,$d,$e,$f,$g,$h,$i,$j)
{
	$this->q_id=$a;
	$this->examid=$b;
	$this->question=$c;
	$this->op1=$d;
	$this->op2=$d;
	$this->op3=$d;
	$this->op4=$d;
	$this->level=$d;
	$this->topic=$d;
	}


	
public function display_all()
	{
   	$output="";
	$output.="<br/> q_id=".$this->q_id;
	$output.="<br/> examid=".$this->examid;
	$output.="<br/> question=".$this->question;	
	$output.="<br/> option1 =".$this->op1;
	$output.="<br/> option2=".$this->op2;
	$output.="<br/> option3=".$this->op3;
	$output.="<br/> option4 =".$this->op4;
	$output.="<br/> correct_ans=".$this->correct_ans;
	$output.="<br/> level=".$this->level;
	$output.="<br/> topic=".$this->topic;
	$output.=fetch_scalardata($query);
	}

public function savetodb()
	{


$query= "insert into 111_qu_paper values('$this->q_id','$this->examid','$this->question','$this->op1','$this->op2','$this->op3','$this->op4','$this->correct_ans','$this->level','$this->topic');";


		echo "<br/>$query";
		$n=my_uid($query);
		echo "<br/>$n record saved";
	}

}




?>