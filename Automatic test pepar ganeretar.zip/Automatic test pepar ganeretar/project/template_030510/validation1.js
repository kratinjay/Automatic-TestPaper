// confirm password
function chkpwd()
{
a=document.getElementById('pwd').value;
b=document.getElementById('pwd1').value;
if(a!=b)
{
alert("Password mismatched");
}
}

//javascript udf
function msg(spid,msg)	
{
spid.innerHTML="<font color=blue>"+ msg + "</font>";
}

function info(spid,fld)
{
spid.innerHTML="No of chars = "+fld.value.length;
}


function chk_alpha(spid,fld,ln,sptoclear)
{
//a (this), to show information about this(form field)
//b is span where error message or ok message would be shown
//c is minimum number of chars
//d is message span to be cleared
ok=true; //assuming data is valid
sptoclear.innerHTML="";

x=fld.value.length;
if (x<ln)
	ok=false;
for(i=0;i<x;i++)
	{
	y=fld.value.charCodeAt(i);
	if ( !(  (y>=65 && y<=90) ||(y>=97 && y<=122 ) || (y==32)))
		ok=false;
	}	


if(ok)
	spid.innerHTML="<font color=green>OK</font>";
else
	spid.innerHTML="<font color=red>not all alphabets, check again</font>";
}




function chk_digits(spid,fld,ln,sptoclear)
{
ok=true; //assuming data is valid
sptoclear.innerHTML="";
x=fld.value.length;
if (x<ln)
	{
	ok=false;
	emsg="Length is less than "+ln;
	}
else
{
for(i=0;i<x;i++)
	{
	y=fld.value.charCodeAt(i);
	if ( !  (y>=48 && y<=57))
		{		
		ok=false;
		emsg="Not all numbers";
		break;
		}
	}	
}

if(ok)
	spid.innerHTML="<font color=green>OK</font>";
else
	spid.innerHTML="<font color=red>"+ emsg +"</font>";
}

function chk_email(spid,a,sptoclear)
{
//a (this), to show information about this(form field)


// only one @
// no spaces
//can have [a-z][A-Z][0-9][.][ _ ][@]
// cant have [..]
// cant have [.@]
// cant have [@.]


// can start with alpha or digit only

ok=true;

// @ must be once only
if(a.value.indexOf('@')!=a.value.lastIndexOf('@'))
		ok=false;

// .. cant be part of valid email
if(a.value.indexOf('..')!=-1)
		ok=false;

// .@ cant be part of valid email
if(a.value.indexOf('.@')!=-1)
		ok=false;

// @. cant be part of valid email
if(a.value.indexOf('@.')!=-1)
		ok=false;

// one . should be there after @
if (  !(a.value.lastIndexOf('.')> a.value.indexOf('@') +1 )  )
		ok=false;


// no spaces allowed
if(a.value.indexOf(' ')!= -1)
		ok=false;


// only [a-z][A-Z][0-9][.][ _ ][@] chars are allowed

x=a.value.length;
//str="";
for(i=0;i<x;i++)
	{
	y=a.value.charCodeAt(i);
	//str=str+ y + " | ";
	if ( !(  (y>=65 && y<=90) ||(y>=97 && y<=122 ) ||(y>=48 && y<=57 ) || (y==46 ) || (y==95 )|| (y==64)  )   )
		ok=false;
	}	


// must begun with digit or alpha
y=a.value.charCodeAt(0);
	if ( !(  (y>=65 && y<=90) ||(y>=97 && y<=122 ) ||(y>=48 && y<=57 )))
	ok=false;
//alert(str+ ok);
if(ok)
	spid.innerHTML="<font color=green>OK</font>";
else
	spid.innerHTML="<font color=red>not a valid email address</font>";

sptoclear.innerHTML=" ";

} //end of val_email function