<?php
@session_start();
include_once 'dbconfig.php';
$u=@$_SESSION['sun'];
$p=@$_SESSION['sup'];
$rem=false;
$msg1="";
if(verifyuser($u,$p,$rem))
{
$msg1="<br/>Mode: Admin , Welcome $u, <a href=logout.php>Logout</a>";
}
else
{
	if(verifystudent($u,$p,$rem))
	{
	$msg1="<br/>Mode: Student , Welcome $u, <a href=logout.php>Logout</a>";
	}
	else
	{
	header("Location:loginerr.php");
	}

}
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

	<title>Online Test</title>
	<link rel="stylesheet" href="style.css" type="text/css" charset="utf-8" />
</head>

<body>
<div id="container">
	<div id="menu">

	<?php include "toplinks.php"; ?>
	
	</div>
	<div id="header">
		<div id="logo">
			<a href=" "><img src="images/logo.gif" alt="logo" border="0" /></a>
		</div>
<div id="right">
		<?php
		echo $msg1;
		?>
		</div>
		<div id="welcome">
			<h2>Results</h2>

<form name=f1 id=f1  >
<table BGCOLOR = BLACK align = center border=0>
<tr>
<td>Exam Id</td>
<td>
<?php
$query="select exam_id,concat_ws(',',topic,doe) from 111_exam_info";
echo my_show_select('examid',$query,1,false,0);
?>
</td>
</tr>
<tr>

<td colspan=2 align=center><br/><input type=submit name=exam id=exam value=" show result " size = 15/></td>

</tr>
<tr>

<td colspan=2 align=center>

<?php
if(isset($_REQUEST['exam']))
{
$x=$_REQUEST['examid'];
$examid=$x;
$query="select * from  111_exam_info where exam_id='$x'";
$rs=my_select($query);
$row=mysql_fetch_array($rs);

echo "<table bgcolor= blue width=300>";
	foreach($row as $k=>$v)
		{
                 echo "<tr bgcolor=blue >"; 
			if(!(is_numeric($k)))
			{
echo "<td>$k</td>";							
echo "<td>$v</td>";
			}

echo "</tr>";
		}

echo "</table>";

?>
</td></tr>
<?php
$query="select rollno,sum(marks) as result from 111_attempt_a group by examid,rollno having examid='$x'  order by result ";
$rs=my_select($query);
echo "<table border=1 align=center width=300>";
echo "<tr><td>Rollno</td><td>Name</tD><td>Marks</td></tR>";
while($row=mysql_fetch_array($rs))
{
$query="select name from 111_user_student where roll_no='$row[0]'";
$name=fetch_scalardata($query);

echo "<tr><td>$row[0]</td><td>$name</tD><td>$row[1]</td></tR>";
}
echo "</table>";
?>
<tr><td></tD></tR>
</table>
<?php
}
?>
</form>		

		</div>

		<div class="clear"></div>

	</div>

	<div id="middle"></div>
	<div id="middle2"></div>
	<div id="content">
		<div id="left">
			<h2>Up	oming Exams</h2>
			<?php @include 'upcoming.php'; ?>
			
		</div>
		<div id="right">
			<h2>Results</h2>
			<br /><br />
			<a class="more" href="results.php">more results</a>
		</div>
		<div class="clear"></div>
	</div>
	
	<div id="footer">
		<p>Copyright � Satyavaib softwares 2010  <a href="termsofuse.php">Terms of use</a><p>
		
	</div>

</div>
</body>
</html>
