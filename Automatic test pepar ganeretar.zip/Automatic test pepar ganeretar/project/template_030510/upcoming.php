<h2>New events</h2>
			
			<p><font color = green>NOVIZIO 2K10</font></p>
			<p>for registration in NOVIZIO 2K10  go to -><a href="http://nrigroupindia.com/novizio">NRI</a> </p>
			<p>RHCE  <a href="http://linux.org"><font color= red >Click me</font></a>.</p>
			