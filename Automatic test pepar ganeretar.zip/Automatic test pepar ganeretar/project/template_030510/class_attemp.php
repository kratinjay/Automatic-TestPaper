<?php
include_once 'dbconfig.php';
class attemp
{
private $attemp_id;
private $email;
private $branch;
private $q_id;
private $ans;
private $verified;



//accessor and mutetar function for create



public function get_attemp_id()
{
	return $this->attemp_id;
}
public function set_attemp_id($x)
{
	$this->attemp_id=$x;
}
public function get_email()
{
	return $this->email;
}
public function set_email($x)
{
	$this->email=$x;
}
public function get_branch()
{
	return $this->branch;
}
public function set_branch($x)
{
	$this->branch=$x;
}
public function get_q_id()
{
	return $this->q_id;
}
public function set_q_id($x)
{
	$this->q_id=$x;
}

public function get_ans()
{
	return $this->ans;
}
public function set_ans($x)
{
	$this->ans=$x;
}
public function get_verified()
{
	return $this->verified;
}
public function set_verified($x)
{
	$this->verified=$x;
}


public function set_all($a,$b,$c,$d,$e,$f)
{
	$this->attemp_id=$a;
	$this->email=$b;
	$this->branch=$c;
	$this->q_id=$d;
	$this->ans=$e;
	$this->verified=$f;
}
public function display_all()
{
   $output="";
	$output.="<br/> attemp_id=".$this->attemp_id;
	$output.="<br/> student email=".$this->email;
	$output.="<br/> branch=".$this->branch;
	$output.="<br/> q_id=".$this->q_id;
	$output.="<br/>ans=".$this->ans;
	$output.="<br/> verified=".$this->verified;
	
	$output.=fetch_scalardata($query);
	
}

public function savetodb()
	{
		$query="insert into 111_attemp_q values('$this->attemp_id','$this->email','$this->branch','$this->q_id','$this->ans','$this->verified')";



		echo "<br/>$query";
		$n=my_uid($query);
		echo "<br/>$n record saved";
	}

public function modifirec()
	{
		$query="update 111_attemp_q set email='$this->email',branch='$this->branch',q_id='$this->q_id',ans='$this->ans',verified='$this->verified' where attemp_id='$this->attemp_id' ";


		echo "<br/>$query";
		$n=my_uid($query);
		echo "<br/>$n records modified";
		return $n;
	}	


public function removerec()
	{
$query="delete from 111_attemp_q  where attemp_id='$this->attemp_id' ";
echo "<br/>$query";
$n=my_uid($query);
echo "<br/>$n records removed";
return $n;

    }

public function searchdata()
{
$query="select * from 111_attemp_q";
echo "<br/>$query";
$rs=my_select($query);
$output="";
while($row=mysql_fetch_array($rs))
{
	foreach($row as $k=>$v)
		{
			if(!(is_numeric($k)))
			{
				$output.="<br/>$k is $v";
				$output.="<hr/>";
			}

		}
}
return $output;
}





}




?>