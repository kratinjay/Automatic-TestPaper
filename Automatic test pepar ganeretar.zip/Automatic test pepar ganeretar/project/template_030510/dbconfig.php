<?php
$local=1;
if($local==1)
{

$dbserver="localhost";
$dbuser="root";
$dbpwd="mysql";
$dbname="exam_form";
$bgclrl='pink';
$borderclrl='silver';
$titleclrl='red';
$correct=3;
$incorrect=-1;

}
else
{

$dbserver="www.youtube.com";
$dbuser="satyendra";
$dbpwd="bhopal";

$dbname="satyendra";
}


function my_select($query)
{

global $dbserver,$dbuser,$dbpwd,$dbname;

$cid=mysql_connect($dbserver,$dbuser,$dbpwd) or die('try again');

mysql_select_db($dbname,$cid);
$rs=mysql_query($query,$cid);
mysql_close($cid);
return $rs;
}

function my_uid($query)
{

global $dbserver,$dbuser,$dbpwd,$dbname;

$cid=mysql_connect($dbserver,$dbuser,$dbpwd) or die('try again');

mysql_select_db($dbname,$cid);
mysql_query($query,$cid);

$n=mysql_affected_rows($cid);
mysql_close($cid);
return $n;
}

function my_show_select($dd_name,$query,$nrow,$multiple,$s_value)
{

   if($multiple==true)
      {
 $output="<select name='$dd_name' id='$dd_name' size='$nrow' multiple>";

       }
  else
     { 
      $output="<select name='$dd_name' id='$dd_name' size='$nrow'>";

        }

 $rs=my_select($query);
  while($row=mysql_fetch_array($rs))
    {  
      if($row[0]==$s_value)
          {
           $output.="<option value='$row[0]' selected >$row[1]</option>";
             }


       else
            {
	   $output.="<option value='$row[0]'> $row[1] </option>";
		}

       }
$output.="</select>";

return $output;

}



function verifyuser($u,$p,$rem)
{
$query="select count(*) from 111_login_id where username='$u' and password='$p' ";
//echo "<br/>$query";
$rs=my_select($query);
$row=mysql_fetch_array($rs);
if($row[0]==1)
{
@session_start(); //notice supress
$_SESSION['sun']=$u;
$_SESSION['sup']=$p;
if($rem)
{
//create cookie
setcookie('username',$u,time()+60*60*24*30);
setcookie('userpwd',$p,time()+60*60*24*30);
}
return true;
}
else
return false;
}

function fetch_scalardata($query)
{

$rs=my_select($query);
$row=mysql_fetch_array($rs);
$output=$row[0];
return $output;
}

function verifystudent($u,$p,$rem)
{
$query="select count(*) from 111_user_student where roll_no='$u' and pwd='$p' ";
//echo "<br/>$query";
$rs=my_select($query);
$row=mysql_fetch_array($rs);
if($row[0]==1)
{
@session_start(); //notice supress
$_SESSION['sun']=$u;
$_SESSION['sup']=$p;
if($rem)
{
//create cookie
setcookie('username',$u,time()+60*60*24*30);
setcookie('userpwd',$p,time()+60*60*24*30);
}
return true;
}
else
return false;
}

?>