<!-- toplinks centralised here -->
<ul>
	<li id="m01"><a href="index.php">Home</a></li>

	<li id="m02"><a href="exam_info.php">Exams</a></li>
	<li id="m03"><a href="user_student.php ">Student</a></li>
	<li id="m04"><a href="attemp_q.php">Attempt</a></li>
	<li id="m05"><a href="examlevel.php">levels</a></li>
	<li id="m06"><a href="que.php"> questions</a></li>
	<li id="m07"><a href="result.php">Results</a></li>
</ul>
