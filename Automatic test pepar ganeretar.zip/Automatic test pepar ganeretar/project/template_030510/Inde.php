
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

	<title>Online Test</title>
	<link rel="stylesheet" href="style.css" type="text/css" charset="utf-8" />
</head>

<body>
<div id="container">
	<div id="menu">

	<?php include "toplinks.php"; ?>
	
	</div>
	<div id="header">
		<div id="logo">
			<a href=" "><img src="images/logo.gif" alt="logo" border="0" /></a>
		</div>
		<div id="dj"></div>
		<div id="welcome">
			<h2></h2>
			<a href="login.php"><img src="images/here.gif" alt="photo 1" /></a>
			 <p align=center>New User  <a href="signup.php ">Signup Here</a></p> 
			
			<a class="more" href=" "></a>
		</div>
		<div class="clear"></div>
	</div>
	<div id="middle"></div>
	<div id="middle2"></div>
	<div id="content">
		<div id="left">
			<h2>News events</h2>
			
			<p>This is just a place holder so you can see how the site would look like.</p>
			<p>The template is designed by <a href=" ">free website templates</a> for you for free you can replace all the text by your own text.</p>
			<p>Even more websites all about website templates on <a href="http://www.justwebtemplates.com">Just Web Templates</a>.</p>
			<p>If you're looking for beautiful and professionally made templates you can find them at <a href="http://www.templatebeauty.com">Template Beauty</a>.</p>
		</div>
		<div id="right">
			<h2>Photos</h2>
			<a href=" "><img src="images/photo1.jpg" alt="photo 1" /></a>
			<a href=" "><img src="images/photo2.jpg" alt="photo 2" /></a>
			<a href=" "><img src="images/photo3.jpg" alt="photo 3" /></a>
			<a href=" "><img src="images/photo4.jpg" alt="photo 4" /></a>
			<br /><br />
			<a class="more" href=" ">more photos</a>
		</div>
		<div class="clear"></div>
	</div>
	
	<div id="footer">
		<p>Copyright � Satyavaib softwares 2010  <a href="termsofuse.php">Terms of use</a><p>
		
	</div>

</div>
</body>
</html>
