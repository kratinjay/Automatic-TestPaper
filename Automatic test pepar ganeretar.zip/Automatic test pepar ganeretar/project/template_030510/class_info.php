<?php
include_once 'dbconfig.php';
class exam
{
private $exam_id;
private $doe;
private $duration;
private $topic;
private $no_of_q;
private $branch;
private $sem;
private $sub;


//accessor and mutetar function for create



public function get_exam_id()
{
	return $this->exam_id;
}
public function set_exam_id($x)
{
	$this->exam_id=$x;
}
public function get_doe()
{
	return $this->doe;
}
public function set_doe($x)
{
	$this->doe=$x;
}
public function get_duration()
{
	return $this->duration;
}
public function set_duration($x)
{
	$this->duration=$x;
}
public function get_topic()
{
	return $this->topic;
}
public function set_topic($x)
{
	$this->topic=$x;
}
public function get_no_of_q()
{
	return $this->no_of_q;
}
public function set_no_of_q($x)
{
	$this->no_of_q=$x;
}

public function get_branch()
{
	return $this->branch;
}
public function set_branch($x)
{
	$this->branch=$x;
}
public function get_sem()
{
	return $this->sem;
}
public function set_sem($x)
{
	$this->sem=$x;
}
public function get_sub()
{
	return $this->sub;
}
public function set_sub($x)
{
	$this->sub=$x;
}


public function set_all($a,$b,$c,$d,$e,$f,$g,$h)
{
	$this->exam_id=$a;
	$this->doe=$b;
	$this->duration=$c;
	$this->topic=$d;
	$this->no_of_q=$e;
	$this->branch=$f;
	$this->sem=$g;
	$this->sub=$h;
}
public function display_all()
{
   $output="";
	$output.="<br/> exam_id=".$this->exam_id;
	$output.="<br/> student doe=".$this->doe;
	$output.="<br/> duration=".$this->duration;
	$output.="<br/> topic=".$this->topic;
	$output.="<br/> no_of_q=".$this->no_of_q;
	$output.="<br/>branch=".$this->branch;
	$output.="<br/> sem=".$this->sem;
	$output.="<br/> subject=".$this->sub;
	
	$output.=fetch_scalardata($query);
	
}

public function savetodb()
	{
		$query="insert into 111_exam_info values('$this->exam_id','$this->doe','$this->duration','$this->topic','$this->no_of_q','$this->branch','$this->sem','$this->sub')";



		//echo "<br/>$query";
		$n=my_uid($query);
		echo "<br/>record saved";
	}

public function modifirec()
	{
		$query="update 111_exam_info set doe='$this->doe',duration='$this->duration',topic='$this->topic',no_of_q='$this->no_of_q',branch='$this->branch',
		sem='$this->sem',sub='$this->sub' where exam_id='$this->exam_id' ";


		//echo "<br/>$query";
		$n=my_uid($query);
		echo "<br/>records modified";
		return $n;
	}	


public function removerec()
	{
$query="delete from 111_exam_info where exam_id='$this->exam_id' ";
//echo "<br/>$query";
$n=my_uid($query);
echo "<br/> RECORDS DELETE";
return $n;

    }

public function searchdata()
{
$query="select * from 111_exam_info";

$rs=my_select($query);
$output="";
while($row=mysql_fetch_array($rs))
{
	foreach($row as $k=>$v)
		{
			if(!(is_numeric($k)))
			{
				$output.="<br/>$k is $v";
				
			}


		}
$output.="<br/>&nbsp;<br/>&nbsp;";
}
return $output;
}

}

?>